import { useEffect, useState } from "react";
import type { Session, User } from "@supabase/supabase-js";
import { supabase } from "@/integrations/supabase/client";

export type AppRole = "admin" | "doctor" | "patient";

export interface AuthState {
  session: Session | null;
  user: User | null;
  role: AppRole | null;
  loading: boolean;
}

export function useAuth(): AuthState {
  const [session, setSession] = useState<Session | null>(null);
  const [role, setRole] = useState<AppRole | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const { data: sub } = supabase.auth.onAuthStateChange((_e, s) => {
      setSession(s);
      if (!s) {
        setRole(null);
        setLoading(false);
      } else {
        // Defer role fetch to avoid deadlock inside callback
        setTimeout(() => fetchRole(s.user.id), 0);
      }
    });
    supabase.auth.getSession().then(({ data }) => {
      setSession(data.session);
      if (data.session) fetchRole(data.session.user.id);
      else setLoading(false);
    });
    return () => sub.subscription.unsubscribe();

    async function fetchRole(uid: string) {
      const { data } = await supabase
        .from("user_roles")
        .select("role")
        .eq("user_id", uid)
        .order("role")
        .limit(1)
        .maybeSingle();
      // Priority: admin > doctor > patient
      const { data: all } = await supabase
        .from("user_roles")
        .select("role")
        .eq("user_id", uid);
      const roles = (all ?? []).map((r) => r.role as AppRole);
      const resolved: AppRole = roles.includes("admin")
        ? "admin"
        : roles.includes("doctor")
          ? "doctor"
          : roles.includes("patient")
            ? "patient"
            : ((data?.role as AppRole) ?? "patient");
      setRole(resolved);
      setLoading(false);
    }
  }, []);

  return { session, user: session?.user ?? null, role, loading };
}

export function roleHome(role: AppRole | null): string {
  if (role === "admin") return "/admin";
  if (role === "doctor") return "/doctor";
  return "/patient";
}
