import { createFileRoute, Link } from "@tanstack/react-router";
import { motion } from "motion/react";
import { Activity, CalendarCheck, HeartPulse, ShieldCheck, Stethoscope, Users } from "lucide-react";
import { ThemeToggle } from "@/components/theme-toggle";

export const Route = createFileRoute("/")({
  component: Landing,
});

function Landing() {
  return (
    <div className="min-h-screen">
      <header className="mx-auto flex max-w-7xl items-center justify-between px-6 py-5">
        <Link to="/" className="flex items-center gap-2 font-display text-lg font-semibold">
          <span className="gradient-primary flex h-9 w-9 items-center justify-center rounded-xl shadow-elegant">
            <HeartPulse className="h-5 w-5 text-primary-foreground" />
          </span>
          Aurora Health
        </Link>
        <nav className="hidden items-center gap-8 text-sm text-muted-foreground md:flex">
          <a href="#features" className="hover:text-foreground transition">Features</a>
          <a href="#portals" className="hover:text-foreground transition">Portals</a>
          <a href="#trust" className="hover:text-foreground transition">Security</a>
        </nav>
        <div className="flex items-center gap-2">
          <ThemeToggle />
          <Link to="/auth" className="glass rounded-full px-4 py-2 text-sm font-medium">Sign in</Link>
          <Link
            to="/auth"
            search={{ mode: "signup" } as never}
            className="gradient-primary text-primary-foreground rounded-full px-4 py-2 text-sm font-medium shadow-elegant"
          >
            Get started
          </Link>
        </div>
      </header>

      <section className="mx-auto max-w-7xl px-6 pt-16 pb-24 text-center md:pt-24">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="mx-auto max-w-3xl"
        >
          <div className="glass mx-auto mb-6 inline-flex items-center gap-2 rounded-full px-4 py-1.5 text-xs">
            <span className="h-1.5 w-1.5 rounded-full bg-primary" /> New — Teleconsultations now live
          </div>
          <h1 className="text-4xl font-bold leading-tight font-display sm:text-6xl">
            The <span className="text-gradient">modern operating system</span><br /> for your hospital
          </h1>
          <p className="mt-6 text-lg text-muted-foreground">
            Aurora Health unifies appointments, records, billing, and telehealth in one calm,
            premium workspace — built for admins, doctors, and patients alike.
          </p>
          <div className="mt-8 flex flex-wrap justify-center gap-3">
            <Link
              to="/auth"
              search={{ mode: "signup" } as never}
              className="gradient-primary text-primary-foreground rounded-full px-6 py-3 text-sm font-semibold shadow-elegant transition hover:opacity-90"
            >
              Create your account
            </Link>
            <Link to="/auth" className="glass rounded-full px-6 py-3 text-sm font-semibold">
              Sign in
            </Link>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.15 }}
          className="glass-strong mx-auto mt-16 grid max-w-5xl grid-cols-2 gap-6 rounded-3xl p-8 md:grid-cols-4"
        >
          {[
            { k: "12k+", v: "Patients cared for" },
            { k: "480", v: "Active clinicians" },
            { k: "99.98%", v: "Uptime" },
            { k: "HIPAA", v: "Compliant by design" },
          ].map((s) => (
            <div key={s.v} className="text-center">
              <div className="text-gradient text-3xl font-bold font-display">{s.k}</div>
              <div className="mt-1 text-xs text-muted-foreground">{s.v}</div>
            </div>
          ))}
        </motion.div>
      </section>

      <section id="features" className="mx-auto max-w-7xl px-6 py-16">
        <div className="mx-auto mb-12 max-w-2xl text-center">
          <h2 className="text-3xl font-bold font-display sm:text-4xl">Everything a hospital runs on</h2>
          <p className="mt-3 text-muted-foreground">One coherent platform. Zero context switching.</p>
        </div>
        <div className="grid gap-6 md:grid-cols-3">
          {features.map((f, i) => (
            <motion.div
              key={f.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: i * 0.05 }}
              className="glass rounded-3xl p-6 transition hover:-translate-y-1 hover:shadow-elegant"
            >
              <div className="gradient-primary mb-4 flex h-11 w-11 items-center justify-center rounded-xl shadow-elegant">
                <f.icon className="h-5 w-5 text-primary-foreground" />
              </div>
              <h3 className="text-lg font-semibold">{f.title}</h3>
              <p className="mt-2 text-sm text-muted-foreground">{f.desc}</p>
            </motion.div>
          ))}
        </div>
      </section>

      <section id="portals" className="mx-auto max-w-7xl px-6 py-16">
        <div className="grid gap-6 md:grid-cols-3">
          {portals.map((p) => (
            <div key={p.title} className="glass-strong rounded-3xl p-8">
              <p.icon className="text-primary mb-4 h-6 w-6" />
              <h3 className="text-xl font-semibold font-display">{p.title}</h3>
              <p className="mt-2 text-sm text-muted-foreground">{p.desc}</p>
              <ul className="mt-4 space-y-1.5 text-sm text-muted-foreground">
                {p.bullets.map((b) => (
                  <li key={b} className="flex items-center gap-2">
                    <span className="h-1 w-1 rounded-full bg-primary" /> {b}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </section>

      <footer id="trust" className="mx-auto mt-8 max-w-7xl border-t border-border px-6 py-10 text-sm text-muted-foreground">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>© {new Date().getFullYear()} Aurora Health — built with care.</div>
          <div className="flex items-center gap-4">
            <span className="flex items-center gap-1.5"><ShieldCheck className="h-4 w-4" /> Encrypted at rest & in transit</span>
          </div>
        </div>
      </footer>
    </div>
  );
}

const features = [
  { icon: CalendarCheck, title: "Smart appointments", desc: "Real-time scheduling with intelligent queues, calendar sync, and automated reminders." },
  { icon: Activity, title: "Live analytics", desc: "Revenue, occupancy and clinician performance beautifully visualized." },
  { icon: Users, title: "Unified profiles", desc: "One record per patient — vitals, history, prescriptions, and insurance in one view." },
];

const portals = [
  { icon: ShieldCheck, title: "Admin", desc: "Run the entire hospital.", bullets: ["Patients & doctors", "Departments, rooms, beds", "Billing & reports", "Audit logs"] },
  { icon: Stethoscope, title: "Doctor", desc: "Focus on care.", bullets: ["Today's queue", "Consultations & prescriptions", "Lab reports", "Teleconsult"] },
  { icon: HeartPulse, title: "Patient", desc: "Own your health.", bullets: ["Book & manage visits", "Records & prescriptions", "Pay invoices online", "Chat with your doctor"] },
];

