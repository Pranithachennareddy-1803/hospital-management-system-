import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { motion } from "motion/react";
import { CalendarCheck, FileText, HeartPulse, Sparkles } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";

export const Route = createFileRoute("/_authenticated/patient/")({
  component: PatientDashboard,
});

function PatientDashboard() {
  const { user } = useAuth();
  const { data: profile } = useQuery({
    queryKey: ["patient-profile", user?.id],
    enabled: !!user?.id,
    queryFn: async () => {
      const { data } = await supabase.from("profiles").select("full_name, email").eq("id", user!.id).maybeSingle();
      return data;
    },
  });

  const kpis = [
    { label: "Upcoming visit", value: "—", icon: CalendarCheck },
    { label: "Recent reports", value: 0, icon: FileText },
    { label: "Health score", value: "92", icon: HeartPulse },
    { label: "Insights", value: "3", icon: Sparkles },
  ];

  const name = profile?.full_name?.split(" ")[0] ?? "there";

  return (
    <div className="space-y-6 pt-2">
      <div>
        <h1 className="text-3xl font-bold font-display">Hi {name} 👋</h1>
        <p className="text-sm text-muted-foreground">Your care in one place.</p>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {kpis.map((k, i) => (
          <motion.div
            key={k.label}
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.35, delay: i * 0.05 }}
            className="glass rounded-3xl p-5"
          >
            <div className="flex items-start justify-between">
              <div>
                <div className="text-xs text-muted-foreground">{k.label}</div>
                <div className="mt-1 text-3xl font-bold font-display">{k.value}</div>
              </div>
              <div className="gradient-primary flex h-10 w-10 items-center justify-center rounded-xl shadow-elegant">
                <k.icon className="h-5 w-5 text-primary-foreground" />
              </div>
            </div>
          </motion.div>
        ))}
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <div className="glass-strong rounded-3xl p-8">
          <h2 className="text-xl font-semibold font-display">Book your next visit</h2>
          <p className="mt-2 text-sm text-muted-foreground">
            Browse specialists across our network and reserve a time that works for you.
          </p>
          <Link
            to="/patient/appointments"
            className="gradient-primary text-primary-foreground mt-5 inline-flex rounded-full px-5 py-2.5 text-sm font-semibold shadow-elegant"
          >
            Book appointment
          </Link>
        </div>
        <div className="glass rounded-3xl p-6">
          <h2 className="mb-4 font-semibold font-display">Care team</h2>
          <div className="rounded-2xl border border-dashed border-border p-10 text-center text-sm text-muted-foreground">
            You'll see your assigned clinicians here after your first visit.
          </div>
        </div>
      </div>
    </div>
  );
}
