import { createFileRoute, Outlet } from "@tanstack/react-router";
import { Loader2 } from "lucide-react";
import { PortalShell } from "@/components/portal-shell";
import { useAuth } from "@/lib/auth";

export const Route = createFileRoute("/_authenticated/patient")({
  component: PatientShell,
});

function PatientShell() {
  const { role, loading } = useAuth();
  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <Loader2 className="text-primary h-6 w-6 animate-spin" />
      </div>
    );
  }
  // Everyone can access their patient view.
  void role;
  return (
    <PortalShell role="patient">
      <Outlet />
    </PortalShell>
  );
}
