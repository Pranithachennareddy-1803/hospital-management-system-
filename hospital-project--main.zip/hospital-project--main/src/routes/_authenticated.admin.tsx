import { createFileRoute, Outlet, Navigate } from "@tanstack/react-router";
import { Loader2 } from "lucide-react";
import { PortalShell } from "@/components/portal-shell";
import { useAuth } from "@/lib/auth";

export const Route = createFileRoute("/_authenticated/admin")({
  component: AdminShell,
});

function AdminShell() {
  const { role, loading } = useAuth();
  if (loading) return <Loader className="admin" />;
  if (role !== "admin") return <Navigate to="/" replace />;
  return (
    <PortalShell role="admin">
      <Outlet />
    </PortalShell>
  );
}
function Loader({ className }: { className?: string }) {
  return (
    <div data-scope={className} className="flex min-h-screen items-center justify-center">
      <Loader2 className="text-primary h-6 w-6 animate-spin" />
    </div>
  );
}
