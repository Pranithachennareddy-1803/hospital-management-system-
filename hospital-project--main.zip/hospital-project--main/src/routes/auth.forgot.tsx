import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { HeartPulse, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/auth/forgot")({
  head: () => ({ meta: [{ title: "Reset password — Aurora Health" }] }),
  component: Forgot,
});

function Forgot() {
  const [loading, setLoading] = useState(false);
  const [sent, setSent] = useState(false);

  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    setLoading(true);
    const { error } = await supabase.auth.resetPasswordForEmail(String(fd.get("email")), {
      redirectTo: `${window.location.origin}/auth/reset-password`,
    });
    setLoading(false);
    if (error) return toast.error(error.message);
    setSent(true);
    toast.success("Check your email for a reset link");
  }

  return (
    <div className="min-h-screen">
      <div className="mx-auto flex max-w-7xl items-center justify-between px-6 py-5">
        <Link to="/" className="flex items-center gap-2 font-display text-lg font-semibold">
          <span className="gradient-primary flex h-9 w-9 items-center justify-center rounded-xl">
            <HeartPulse className="h-5 w-5 text-primary-foreground" />
          </span>
          Aurora Health
        </Link>
        <Link to="/auth" className="text-sm text-muted-foreground hover:text-foreground">← Back to sign in</Link>
      </div>
      <div className="mx-auto max-w-md px-6 pt-8">
        <div className="glass-strong rounded-3xl p-8">
          <h1 className="text-2xl font-bold font-display">Reset your password</h1>
          <p className="mt-1 text-sm text-muted-foreground">We'll send you a secure link.</p>
          {sent ? (
            <p className="mt-6 text-sm">If an account exists for that email, a reset link is on its way.</p>
          ) : (
            <form onSubmit={onSubmit} className="mt-6 space-y-4">
              <div>
                <Label htmlFor="email">Email</Label>
                <Input id="email" name="email" type="email" required />
              </div>
              <Button disabled={loading} className="gradient-primary text-primary-foreground w-full rounded-full">
                {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />} Send reset link
              </Button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
}
