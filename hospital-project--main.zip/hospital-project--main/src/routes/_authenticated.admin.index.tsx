import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { motion } from "motion/react";
import { Users, Stethoscope, CalendarCheck, DollarSign } from "lucide-react";
import { Area, AreaChart, Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/_authenticated/admin/")({
  component: AdminDashboard,
});

function AdminDashboard() {
  const { data: stats } = useQuery({
    queryKey: ["admin-stats"],
    queryFn: async () => {
      const [{ count: patients }, { count: doctors }, { count: appts }, today] = await Promise.all([
        supabase.from("patients").select("*", { count: "exact", head: true }),
        supabase.from("doctors").select("*", { count: "exact", head: true }),
        supabase.from("appointments").select("*", { count: "exact", head: true }),
        supabase
          .from("appointments")
          .select("*", { count: "exact", head: true })
          .gte("scheduled_at", new Date(new Date().setHours(0, 0, 0, 0)).toISOString())
          .lt("scheduled_at", new Date(new Date().setHours(24, 0, 0, 0)).toISOString()),
      ]);
      return {
        patients: patients ?? 0,
        doctors: doctors ?? 0,
        appointments: appts ?? 0,
        today: today.count ?? 0,
      };
    },
  });

  const revenueData = Array.from({ length: 12 }, (_, i) => ({
    m: ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"][i],
    revenue: Math.round(40000 + Math.random() * 60000),
  }));
  const apptData = Array.from({ length: 7 }, (_, i) => ({
    d: ["Mon","Tue","Wed","Thu","Fri","Sat","Sun"][i],
    v: Math.round(20 + Math.random() * 60),
  }));

  const kpis = [
    { label: "Total Patients", value: stats?.patients ?? 0, icon: Users, tint: "from-primary/20" },
    { label: "Doctors", value: stats?.doctors ?? 0, icon: Stethoscope, tint: "from-accent/20" },
    { label: "Today's Appointments", value: stats?.today ?? 0, icon: CalendarCheck, tint: "from-primary/20" },
    { label: "Revenue (mo)", value: "$128k", icon: DollarSign, tint: "from-accent/20" },
  ];

  return (
    <div className="space-y-6 pt-2">
      <div>
        <h1 className="text-3xl font-bold font-display">Good day, Admin</h1>
        <p className="text-sm text-muted-foreground">Here's what's happening across the hospital today.</p>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {kpis.map((k, i) => (
          <motion.div
            key={k.label}
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.35, delay: i * 0.05 }}
            className="glass relative overflow-hidden rounded-3xl p-5"
          >
            <div className={`pointer-events-none absolute inset-0 bg-gradient-to-br ${k.tint} to-transparent opacity-60`} />
            <div className="relative flex items-start justify-between">
              <div>
                <div className="text-xs text-muted-foreground">{k.label}</div>
                <div className="mt-1 text-3xl font-bold font-display">{k.value}</div>
              </div>
              <div className="gradient-primary flex h-10 w-10 items-center justify-center rounded-xl shadow-elegant">
                <k.icon className="h-5 w-5 text-primary-foreground" />
              </div>
            </div>
          </motion.div>
        ))}
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        <div className="glass rounded-3xl p-6 lg:col-span-2">
          <div className="mb-4 flex items-center justify-between">
            <h2 className="font-semibold font-display">Revenue</h2>
            <span className="text-xs text-muted-foreground">Last 12 months</span>
          </div>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={revenueData}>
                <defs>
                  <linearGradient id="rev" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="var(--primary)" stopOpacity={0.5} />
                    <stop offset="100%" stopColor="var(--primary)" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                <XAxis dataKey="m" stroke="var(--muted-foreground)" fontSize={12} />
                <YAxis stroke="var(--muted-foreground)" fontSize={12} />
                <Tooltip contentStyle={{ background: "var(--popover)", border: "1px solid var(--border)", borderRadius: 12 }} />
                <Area type="monotone" dataKey="revenue" stroke="var(--primary)" strokeWidth={2} fill="url(#rev)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="glass rounded-3xl p-6">
          <div className="mb-4 flex items-center justify-between">
            <h2 className="font-semibold font-display">Appointments</h2>
            <span className="text-xs text-muted-foreground">This week</span>
          </div>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={apptData}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                <XAxis dataKey="d" stroke="var(--muted-foreground)" fontSize={12} />
                <YAxis stroke="var(--muted-foreground)" fontSize={12} />
                <Tooltip contentStyle={{ background: "var(--popover)", border: "1px solid var(--border)", borderRadius: 12 }} />
                <Bar dataKey="v" fill="var(--accent)" radius={[8, 8, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <div className="glass rounded-3xl p-6">
          <h2 className="mb-4 font-semibold font-display">Recent activity</h2>
          <ul className="space-y-3 text-sm">
            {[
              "Dr. Ada Chen completed 3 consultations",
              "New patient registered — J. Rivera",
              "Invoice #10428 was paid",
              "Appointment rescheduled — 2:30 PM",
            ].map((s) => (
              <li key={s} className="glass flex items-center gap-3 rounded-xl px-4 py-3">
                <span className="h-2 w-2 rounded-full bg-primary" /> {s}
              </li>
            ))}
          </ul>
        </div>
        <div className="glass rounded-3xl p-6">
          <h2 className="mb-4 font-semibold font-display">Quick stats</h2>
          <div className="grid grid-cols-2 gap-3">
            {[
              { l: "Avg. wait time", v: "8m" },
              { l: "Occupancy", v: "72%" },
              { l: "Satisfaction", v: "4.8/5" },
              { l: "No-shows", v: "3.1%" },
            ].map((x) => (
              <div key={x.l} className="glass rounded-2xl p-4">
                <div className="text-xs text-muted-foreground">{x.l}</div>
                <div className="mt-1 text-2xl font-semibold font-display">{x.v}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
