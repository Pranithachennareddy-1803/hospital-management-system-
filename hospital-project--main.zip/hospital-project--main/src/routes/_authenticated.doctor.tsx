import { createFileRoute, Outlet, Navigate } from "@tanstack/react-router";
import { Loader2 } from "lucide-react";
import { PortalShell } from "@/components/portal-shell";
import { useAuth } from "@/lib/auth";

export const Route = createFileRoute("/_authenticated/doctor")({
  component: DoctorShell,
});

function DoctorShell() {
  const { role, loading } = useAuth();
  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <Loader2 className="text-primary h-6 w-6 animate-spin" />
      </div>
    );
  }
  if (role !== "doctor" && role !== "admin") return <Navigate to="/" replace />;
  return (
    <PortalShell role="doctor">
      <Outlet />
    </PortalShell>
  );
}
