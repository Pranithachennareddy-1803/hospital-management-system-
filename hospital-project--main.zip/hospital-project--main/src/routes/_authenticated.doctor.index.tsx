import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { motion } from "motion/react";
import { Users, CalendarCheck, ClipboardList, Clock } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";

export const Route = createFileRoute("/_authenticated/doctor/")({
  component: DoctorDashboard,
});

function DoctorDashboard() {
  const { user } = useAuth();
  const { data } = useQuery({
    queryKey: ["doctor-stats", user?.id],
    enabled: !!user?.id,
    queryFn: async () => {
      const { data: doc } = await supabase.from("doctors").select("id").eq("user_id", user!.id).maybeSingle();
      if (!doc) return { today: 0, upcoming: 0, patients: 0 };
      const start = new Date(); start.setHours(0, 0, 0, 0);
      const end = new Date(); end.setHours(24, 0, 0, 0);
      const [{ count: today }, { count: upcoming }] = await Promise.all([
        supabase.from("appointments").select("*", { count: "exact", head: true })
          .eq("doctor_id", doc.id)
          .gte("scheduled_at", start.toISOString()).lt("scheduled_at", end.toISOString()),
        supabase.from("appointments").select("*", { count: "exact", head: true })
          .eq("doctor_id", doc.id).gt("scheduled_at", end.toISOString()),
      ]);
      return { today: today ?? 0, upcoming: upcoming ?? 0, patients: 0 };
    },
  });

  const kpis = [
    { label: "Today's patients", value: data?.today ?? 0, icon: Users },
    { label: "Upcoming", value: data?.upcoming ?? 0, icon: CalendarCheck },
    { label: "Consultations", value: 0, icon: ClipboardList },
    { label: "Avg. duration", value: "22m", icon: Clock },
  ];

  return (
    <div className="space-y-6 pt-2">
      <div>
        <h1 className="text-3xl font-bold font-display">Welcome back, Doctor</h1>
        <p className="text-sm text-muted-foreground">Your day at a glance.</p>
      </div>
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {kpis.map((k, i) => (
          <motion.div
            key={k.label}
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.35, delay: i * 0.05 }}
            className="glass rounded-3xl p-5"
          >
            <div className="flex items-start justify-between">
              <div>
                <div className="text-xs text-muted-foreground">{k.label}</div>
                <div className="mt-1 text-3xl font-bold font-display">{k.value}</div>
              </div>
              <div className="gradient-primary flex h-10 w-10 items-center justify-center rounded-xl shadow-elegant">
                <k.icon className="h-5 w-5 text-primary-foreground" />
              </div>
            </div>
          </motion.div>
        ))}
      </div>

      <div className="glass rounded-3xl p-6">
        <h2 className="mb-4 font-semibold font-display">Today's queue</h2>
        <div className="rounded-2xl border border-dashed border-border p-10 text-center text-sm text-muted-foreground">
          No patients queued yet. Once appointments are booked, they'll appear here.
        </div>
      </div>
    </div>
  );
}
