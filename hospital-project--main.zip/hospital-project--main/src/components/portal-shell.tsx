import { Link, useNavigate, useRouterState } from "@tanstack/react-router";
import { type ReactNode } from "react";
import {
  Activity, Bell, CalendarCheck, ClipboardList, CreditCard, FileText,
  HeartPulse, Home, LogOut, MessagesSquare, Settings, Stethoscope, User,
  Users, LayoutDashboard, Building2, BarChart3,
} from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { ThemeToggle } from "@/components/theme-toggle";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { useAuth, type AppRole } from "@/lib/auth";
import { cn } from "@/lib/utils";
import { useQueryClient } from "@tanstack/react-query";

type NavItem = { to: string; label: string; icon: typeof Home };

const NAV: Record<AppRole, NavItem[]> = {
  admin: [
    { to: "/admin", label: "Dashboard", icon: LayoutDashboard },
    { to: "/admin/patients", label: "Patients", icon: Users },
    { to: "/admin/doctors", label: "Doctors", icon: Stethoscope },
    { to: "/admin/appointments", label: "Appointments", icon: CalendarCheck },
    { to: "/admin/departments", label: "Departments", icon: Building2 },
    { to: "/admin/billing", label: "Billing", icon: CreditCard },
    { to: "/admin/reports", label: "Reports", icon: BarChart3 },
    { to: "/admin/settings", label: "Settings", icon: Settings },
  ],
  doctor: [
    { to: "/doctor", label: "Dashboard", icon: LayoutDashboard },
    { to: "/doctor/patients", label: "Patients", icon: Users },
    { to: "/doctor/appointments", label: "Appointments", icon: CalendarCheck },
    { to: "/doctor/consultations", label: "Consultations", icon: ClipboardList },
    { to: "/doctor/prescriptions", label: "Prescriptions", icon: FileText },
    { to: "/doctor/messages", label: "Messages", icon: MessagesSquare },
    { to: "/doctor/profile", label: "Profile", icon: User },
  ],
  patient: [
    { to: "/patient", label: "Dashboard", icon: LayoutDashboard },
    { to: "/patient/appointments", label: "Appointments", icon: CalendarCheck },
    { to: "/patient/records", label: "Medical Records", icon: FileText },
    { to: "/patient/billing", label: "Billing", icon: CreditCard },
    { to: "/patient/messages", label: "Messages", icon: MessagesSquare },
    { to: "/patient/profile", label: "Profile", icon: User },
  ],
};

const ROLE_LABEL: Record<AppRole, string> = { admin: "Admin", doctor: "Doctor", patient: "Patient" };

export function PortalShell({ role, children }: { role: AppRole; children: ReactNode }) {
  const { user } = useAuth();
  const navigate = useNavigate();
  const qc = useQueryClient();
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const items = NAV[role];

  const initials = (user?.email ?? "?").slice(0, 2).toUpperCase();

  async function signOut() {
    await qc.cancelQueries();
    qc.clear();
    await supabase.auth.signOut();
    navigate({ to: "/auth", replace: true });
  }

  return (
    <div className="min-h-screen">
      <aside className="glass-strong fixed inset-y-3 left-3 z-40 hidden w-64 flex-col rounded-3xl p-4 md:flex">
        <Link to="/" className="flex items-center gap-2 px-2 py-2 font-display text-lg font-semibold">
          <span className="gradient-primary flex h-9 w-9 items-center justify-center rounded-xl shadow-elegant">
            <HeartPulse className="h-5 w-5 text-primary-foreground" />
          </span>
          Aurora
        </Link>
        <div className="mt-2 mb-4 px-2 text-xs uppercase tracking-wider text-muted-foreground">
          {ROLE_LABEL[role]} portal
        </div>
        <nav className="flex-1 space-y-1">
          {items.map((it) => {
            const active = pathname === it.to || (it.to !== `/${role}` && pathname.startsWith(it.to));
            return (
              <Link
                key={it.to}
                to={it.to}
                className={cn(
                  "flex items-center gap-3 rounded-xl px-3 py-2 text-sm transition",
                  active
                    ? "gradient-primary text-primary-foreground shadow-elegant"
                    : "text-muted-foreground hover:bg-muted hover:text-foreground",
                )}
              >
                <it.icon className="h-4 w-4" />
                {it.label}
              </Link>
            );
          })}
        </nav>
        <button
          onClick={signOut}
          className="mt-4 flex items-center gap-3 rounded-xl px-3 py-2 text-sm text-muted-foreground transition hover:bg-muted hover:text-foreground"
        >
          <LogOut className="h-4 w-4" /> Sign out
        </button>
      </aside>

      <main className="md:pl-72">
        <header className="sticky top-0 z-30 flex items-center justify-between px-4 py-4 md:px-8">
          <div className="glass flex items-center gap-2 rounded-full px-4 py-2 text-xs text-muted-foreground">
            <Activity className="h-3.5 w-3.5 text-primary" /> All systems normal
          </div>
          <div className="flex items-center gap-2">
            <button className="glass flex h-9 w-9 items-center justify-center rounded-full" aria-label="Notifications">
              <Bell className="h-4 w-4" />
            </button>
            <ThemeToggle />
            <div className="glass flex items-center gap-2 rounded-full py-1 pr-3 pl-1">
              <Avatar className="h-7 w-7">
                <AvatarFallback className="gradient-primary text-primary-foreground text-xs">{initials}</AvatarFallback>
              </Avatar>
              <span className="hidden text-xs sm:inline">{user?.email}</span>
            </div>
          </div>
        </header>
        <div className="px-4 pb-16 md:px-8">{children}</div>
      </main>
    </div>
  );
}
