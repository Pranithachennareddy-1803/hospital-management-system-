
-- Roles enum
create type public.app_role as enum ('admin', 'doctor', 'patient');
create type public.appointment_status as enum ('scheduled','confirmed','completed','cancelled','no_show');
create type public.gender_type as enum ('male','female','other','prefer_not_to_say');

-- updated_at helper
create or replace function public.tg_set_updated_at()
returns trigger language plpgsql as $$
begin new.updated_at = now(); return new; end $$;

-- PROFILES
create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null default '',
  email text not null,
  phone text,
  avatar_url text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
grant select, insert, update on public.profiles to authenticated;
grant all on public.profiles to service_role;
alter table public.profiles enable row level security;
create trigger profiles_updated before update on public.profiles for each row execute function public.tg_set_updated_at();

-- USER ROLES
create table public.user_roles (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  role public.app_role not null,
  created_at timestamptz not null default now(),
  unique(user_id, role)
);
grant select on public.user_roles to authenticated;
grant all on public.user_roles to service_role;
alter table public.user_roles enable row level security;

create or replace function public.has_role(_user_id uuid, _role public.app_role)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.user_roles where user_id = _user_id and role = _role)
$$;

create or replace function public.current_user_role()
returns public.app_role language sql stable security definer set search_path = public as $$
  select role from public.user_roles where user_id = auth.uid()
  order by case role when 'admin' then 1 when 'doctor' then 2 else 3 end limit 1
$$;

-- DEPARTMENTS
create table public.departments (
  id uuid primary key default gen_random_uuid(),
  name text not null unique,
  description text,
  icon text,
  created_at timestamptz not null default now()
);
grant select on public.departments to authenticated, anon;
grant all on public.departments to service_role;
alter table public.departments enable row level security;
create policy "departments readable by all" on public.departments for select using (true);
create policy "admins manage departments" on public.departments for all
  using (public.has_role(auth.uid(),'admin')) with check (public.has_role(auth.uid(),'admin'));

-- PATIENTS
create table public.patients (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null unique references auth.users(id) on delete cascade,
  date_of_birth date,
  gender public.gender_type,
  blood_group text,
  address text,
  city text,
  emergency_contact_name text,
  emergency_contact_phone text,
  allergies text,
  medical_history text,
  insurance_provider text,
  insurance_number text,
  assigned_doctor_id uuid,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
grant select, insert, update, delete on public.patients to authenticated;
grant all on public.patients to service_role;
alter table public.patients enable row level security;
create trigger patients_updated before update on public.patients for each row execute function public.tg_set_updated_at();

-- DOCTORS
create table public.doctors (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null unique references auth.users(id) on delete cascade,
  department_id uuid references public.departments(id) on delete set null,
  specialization text not null default '',
  license_number text,
  years_experience int not null default 0,
  consultation_fee numeric(10,2) not null default 0,
  bio text,
  working_days text[] not null default array['Mon','Tue','Wed','Thu','Fri']::text[],
  working_hours_start time not null default '09:00',
  working_hours_end time not null default '17:00',
  is_active boolean not null default true,
  rating numeric(3,2) default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
grant select, insert, update, delete on public.doctors to authenticated;
grant select on public.doctors to anon;
grant all on public.doctors to service_role;
alter table public.doctors enable row level security;
create trigger doctors_updated before update on public.doctors for each row execute function public.tg_set_updated_at();

alter table public.patients
  add constraint patients_assigned_doctor_fk foreign key (assigned_doctor_id) references public.doctors(id) on delete set null;

-- APPOINTMENTS
create table public.appointments (
  id uuid primary key default gen_random_uuid(),
  patient_id uuid not null references public.patients(id) on delete cascade,
  doctor_id uuid not null references public.doctors(id) on delete cascade,
  scheduled_at timestamptz not null,
  duration_minutes int not null default 30,
  status public.appointment_status not null default 'scheduled',
  reason text,
  notes text,
  fee numeric(10,2),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
grant select, insert, update, delete on public.appointments to authenticated;
grant all on public.appointments to service_role;
alter table public.appointments enable row level security;
create trigger appointments_updated before update on public.appointments for each row execute function public.tg_set_updated_at();
create index appointments_scheduled_idx on public.appointments(scheduled_at desc);
create index appointments_doctor_idx on public.appointments(doctor_id);
create index appointments_patient_idx on public.appointments(patient_id);

-- RLS POLICIES

-- profiles
create policy "own profile read" on public.profiles for select using (auth.uid() = id);
create policy "admin read profiles" on public.profiles for select using (public.has_role(auth.uid(),'admin'));
create policy "doctor read profiles" on public.profiles for select using (public.has_role(auth.uid(),'doctor'));
create policy "own profile update" on public.profiles for update using (auth.uid() = id) with check (auth.uid() = id);
create policy "own profile insert" on public.profiles for insert with check (auth.uid() = id);
create policy "admin update profiles" on public.profiles for update using (public.has_role(auth.uid(),'admin')) with check (public.has_role(auth.uid(),'admin'));

-- user_roles
create policy "own roles read" on public.user_roles for select using (auth.uid() = user_id);
create policy "admin read roles" on public.user_roles for select using (public.has_role(auth.uid(),'admin'));

-- patients
create policy "own patient read" on public.patients for select using (auth.uid() = user_id);
create policy "own patient update" on public.patients for update using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "admin manage patients" on public.patients for all using (public.has_role(auth.uid(),'admin')) with check (public.has_role(auth.uid(),'admin'));
create policy "doctor read their patients" on public.patients for select using (
  public.has_role(auth.uid(),'doctor') and exists (
    select 1 from public.appointments a
    join public.doctors d on d.id = a.doctor_id
    where a.patient_id = patients.id and d.user_id = auth.uid()
  )
);

-- doctors
create policy "doctors readable by all authenticated" on public.doctors for select using (true);
create policy "own doctor update" on public.doctors for update using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "admin manage doctors" on public.doctors for all using (public.has_role(auth.uid(),'admin')) with check (public.has_role(auth.uid(),'admin'));

-- appointments
create policy "patient sees own appointments" on public.appointments for select using (
  exists (select 1 from public.patients p where p.id = appointments.patient_id and p.user_id = auth.uid())
);
create policy "patient creates own appointments" on public.appointments for insert with check (
  exists (select 1 from public.patients p where p.id = appointments.patient_id and p.user_id = auth.uid())
);
create policy "patient cancels own appointments" on public.appointments for update using (
  exists (select 1 from public.patients p where p.id = appointments.patient_id and p.user_id = auth.uid())
) with check (
  exists (select 1 from public.patients p where p.id = appointments.patient_id and p.user_id = auth.uid())
);
create policy "doctor sees own appointments" on public.appointments for select using (
  exists (select 1 from public.doctors d where d.id = appointments.doctor_id and d.user_id = auth.uid())
);
create policy "doctor updates own appointments" on public.appointments for update using (
  exists (select 1 from public.doctors d where d.id = appointments.doctor_id and d.user_id = auth.uid())
) with check (
  exists (select 1 from public.doctors d where d.id = appointments.doctor_id and d.user_id = auth.uid())
);
create policy "admin manage appointments" on public.appointments for all using (public.has_role(auth.uid(),'admin')) with check (public.has_role(auth.uid(),'admin'));

-- Signup trigger: create profile + patient record + patient role
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, email, full_name, phone)
  values (new.id, new.email, coalesce(new.raw_user_meta_data->>'full_name',''), new.raw_user_meta_data->>'phone')
  on conflict (id) do nothing;

  insert into public.user_roles (user_id, role) values (new.id, 'patient') on conflict do nothing;
  insert into public.patients (user_id) values (new.id) on conflict (user_id) do nothing;
  return new;
end $$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function public.handle_new_user();

-- Seed departments
insert into public.departments (name, description, icon) values
  ('Cardiology','Heart and cardiovascular care','heart-pulse'),
  ('Neurology','Brain and nervous system','brain'),
  ('Orthopedics','Bones, joints and musculoskeletal','bone'),
  ('Pediatrics','Care for infants, children and adolescents','baby'),
  ('Dermatology','Skin, hair and nail care','sparkles'),
  ('General Medicine','Primary care and general consultation','stethoscope'),
  ('Ophthalmology','Eye and vision care','eye'),
  ('ENT','Ear, nose and throat','ear');
